package com.moxdroidlabs.listviewexample.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.moxdroidlabs.listviewexample.R;
import com.moxdroidlabs.listviewexample.model.Employee;

import java.util.ArrayList;

/**
 * Created by macstudent on 2017-11-28.
 */

public class EmployeeAdapter extends ArrayAdapter<Employee>
{

    public EmployeeAdapter(Context context, ArrayList<Employee> employeeArrayList)
    {
        super(context, 0, employeeArrayList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        // Get the data item for this position
        Employee employee = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null)
        {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_employee, parent, false);
        }

        // Lookup view for data population
        TextView tvEmployeeID = (TextView) convertView.findViewById(R.id.txtEmployeeID);
        TextView tvEmployeeName = (TextView) convertView.findViewById(R.id.txtEmployeeName);

        // Populate the data into the template view using the data object
        tvEmployeeID.setText(String.valueOf(employee.getEmployeeId()));
        tvEmployeeName.setText(employee.getEmployeeName());

        return convertView;
    }
}
