package com.moxdroidlabs.listviewexample;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.moxdroidlabs.listviewexample.model.Employee;

public class EmployeeDetailsActivity extends AppCompatActivity {


    Employee employee;
    public static void startIntent(Context context)
    {
        context.startActivity(new Intent(context,EmployeeDetailsActivity.class));
    }

    public static void startIntent(Context context, Bundle bundle)
    {
        Intent me = new Intent(context,EmployeeDetailsActivity.class);
        me.putExtras(bundle);
        context.startActivity(me);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_details);

        if(getIntent().getExtras()  != null) {
            employee = (Employee) getIntent().getExtras().getSerializable("emp");
            Toast.makeText(this, employee.toString(), Toast.LENGTH_LONG).show();
        }
    }
}
