package com.example.macstudent.databaseapplication;
//4

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.example.macstudent.databaseapplication.db.helper.DBContact;
import com.example.macstudent.databaseapplication.db.model.Contact;

import java.util.List;

public class ContactActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DBContact dbcontact = new DBContact(this); // this is - >pointer of contactctivity

        dbcontact.addContact(new Contact("Ravi", "9100000000"));
        dbcontact.addContact(new Contact("Srinivas", "9199999999"));
        dbcontact.addContact(new Contact("Tommy", "9522222222"));
        dbcontact.addContact(new Contact("Karthik", "9533333333"));

// Reading all contacts
        Log.d("Reading: ", "Reading all contacts..");
        List<Contact> contacts = dbcontact.getAllContacts();

        for (Contact cn : contacts) {
            String log = "Id: " + cn.getID() + " ,Name: " + cn.getName() + " ,Phone: " + cn.getPhoneNumber();
            // Writing Contacts to log
            Log.d("Name: ", log);
        }


    }
}
