package com.example.macstudent.c0718456_cricketplayerrank;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.macstudent.c0718456_cricketplayerrank.R.id.chkRemember;

public class myloginActivity extends AppCompatActivity {
    EditText editTextEmail, editTextPassword;
    // CheckBox chkRemember;
    Button btnLogin;

    // SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mylogin);

        editTextEmail = (EditText) findViewById(R.id.edtEmail);
        editTextPassword = (EditText) findViewById(R.id.edtPassword);
        //  chkRemember = (CheckBox)findViewById(R.id.chkRemember);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (editTextEmail.getText().toString().equals("admin@gmail.com") &&
                        editTextPassword.getText().toString().equals("admin")) {
                    Toast.makeText(getApplicationContext(),
                            "Redirecting...", Toast.LENGTH_SHORT).show();
                    Intent mIntent = new Intent(getApplicationContext(), EnterDetailActivity.class);
                    startActivity(mIntent);
                    setContentView(R.layout.activity_enter_detail);


                } else {
                    Toast.makeText(getApplicationContext(), "Wrong Credentials", Toast.LENGTH_SHORT).show();

                    editTextEmail.setVisibility(View.VISIBLE);
                    editTextEmail.setBackgroundColor(Color.RED);


                }

            }
        });
    }


}


//        protected void onResume() {
//            sharedPreferences = getSharedPreferences("userDetails",MODE_PRIVATE);
//            setSavedDetails();
//            super.onResume();
//
//        }

//        private void setSavedDetails() {
//            String email = sharedPreferences.getString("userEmail",null);
//            String pwd = sharedPreferences.getString("userPassword",null);
//
//            if(email != null && pwd != null) {
//                editTextEmail.setText(email);
//                editTextPassword.setText(pwd);
//                chkRemember.setChecked(true);
//            }
//        }


//        public void onClick(View v) {
//
//            if(chkRemember.isChecked()) {
//                SharedPreferences.Editor mEditor = sharedPreferences.edit();
//                mEditor.putString("userEmail",editTextEmail.getText().toString());
//                mEditor.putString("userPassword",editTextPassword.getText().toString());
//                //mEditor.commit();
//                mEditor.apply();
//            }else{
//                SharedPreferences.Editor mEditor = sharedPreferences.edit();
//                mEditor.putString("userEmail",null);
//                mEditor.putString("userPassword",null);
//                mEditor.apply();
//            }
//            Intent mIntent = new Intent(this,EnterDetailActivity.class);
//            startActivity(mIntent);
//        }










