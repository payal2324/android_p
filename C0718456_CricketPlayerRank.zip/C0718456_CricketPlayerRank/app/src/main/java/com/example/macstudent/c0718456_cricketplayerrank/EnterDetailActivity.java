package com.example.macstudent.c0718456_cricketplayerrank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.macstudent.c0718456_cricketplayerrank.modal.Player;

public class EnterDetailActivity extends AppCompatActivity {
Player p = new Player();
Button btnNext;
    TextView txtPName, txtPGender,txtPBirthDay,txtPCategory,txtPTeamCountry,txtPWickets,txtPRuns,txtPCatch,txtPStumps,txtPTestMatch,txtPOneDayMatch;
TextView txtResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_detail);


        //Spinner sp1, sp2;

        txtPName = (TextView) findViewById(R.id.edtPlayerName);
        txtPGender = (TextView) findViewById(R.id.edtPlayerGender);
        txtPBirthDay = (TextView) findViewById(R.id.edtPlayerBirthday);

        txtPCategory = (TextView) findViewById(R.id.edtPlayerCategory);
        txtPTeamCountry = (TextView) findViewById(R.id.edtPlayerTeamCountry);

        txtPTestMatch = (TextView) findViewById(R.id.edtTestMatch);
        txtPOneDayMatch = (TextView) findViewById(R.id.edtOneDayMatch);
        txtPCatch = (TextView) findViewById(R.id.edtCatches);

        txtPWickets = (TextView) findViewById(R.id.edtWickets);
        txtPStumps = (TextView) findViewById(R.id.edtStumps);
        txtPRuns = (TextView) findViewById(R.id.edtRun);

btnNext.setOnClickListener(new View.OnClickListener(){


    @Override
    public void onClick(View view) {

        int testMatchPoints = 5 *Integer.parseInt(txtPTestMatch.getText().toString());
        int oneDayMatchPoints = 2 * Integer.parseInt(txtPOneDayMatch.getText().toString());
        int catchPoints = 3 * Integer.parseInt(txtPCatch.getText().toString());
        int wicketsPoints = 5 *  Integer.parseInt(txtPWickets.getText().toString());
        int stumpsPoints = 3* Integer.parseInt(txtPStumps.getText().toString());
        int runPoints = 1 * Integer.parseInt(txtPRuns.getText().toString());

int total = testMatchPoints+oneDayMatchPoints+catchPoints+wicketsPoints+stumpsPoints+runPoints;

        txtResult.setText(String.valueOf(total));
        Toast.makeText(getApplicationContext(), "total" + total,Toast.LENGTH_SHORT).show();
    }
});


        }
}
