package com.example.macstudent.c0718456_cricketplayerrank.modal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.macstudent.c0718456_cricketplayerrank.R;

public class DisplayPlayerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_player);
    }
}
