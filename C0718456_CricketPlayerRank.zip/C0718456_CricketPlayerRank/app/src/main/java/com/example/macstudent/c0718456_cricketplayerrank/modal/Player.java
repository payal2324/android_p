package com.example.macstudent.c0718456_cricketplayerrank.modal;

/**
 * Created by macstudent on 2017-12-01.
 */

import java.util.Date;

/**
 * Created by macstudent on 2017-12-01.
 */

public class Player {
    String playerName,gender,playerCategory,teamCountry;
    int testMatch,oneDayMatch,catches,runs,wickets,stumping;
    String birthday;
    int total;

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPlayerCategory() {
        return playerCategory;
    }

    public void setPlayerCategory(String playerCategory) {
        this.playerCategory = playerCategory;
    }

    public String getTeamCountry() {
        return teamCountry;
    }

    public void setTeamCountry(String teamCountry) {
        this.teamCountry = teamCountry;
    }

    public int getTestMatch() {
        return testMatch;
    }

    public void setTestMatch(int testMatch) {
        this.testMatch = testMatch;
    }

    public int getOneDayMatch() {
        return oneDayMatch;
    }

    public void setOneDayMatch(int oneDayMatch) {
        this.oneDayMatch = oneDayMatch;
    }

    public int getCatches() {
        return catches;
    }

    public void setCatches(int catches) {
        this.catches = catches;
    }

    public int getRuns() {
        return runs;
    }

    public void setRuns(int runs) {
        this.runs = runs;
    }

    public int getWickets() {
        return wickets;
    }

    public void setWickets(int wickets) {
        this.wickets = wickets;
    }

    public int getStumping() {
        return stumping;
    }

    public void setStumping(int stumping) {
        this.stumping = stumping;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public Player(String playerName, String gender, String playerCategory, String teamCountry, int testMatch, int oneDayMatch, int catches, int runs, int wickets, int stumping, String birthday) {
        this.playerName = playerName;
        this.gender = gender;
        this.playerCategory = playerCategory;
        this.teamCountry = teamCountry;
        this.testMatch = testMatch;
        this.oneDayMatch = oneDayMatch;
        this.catches = catches;
        this.runs = runs;
        this.wickets = wickets;
        this.stumping = stumping;
        this.birthday = birthday;
    }

    public Player() {
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
    //    3. Player Portfolio Entry Screens Marks (30)
//    a. Player Name
//    b. Gender
//    c. Birthdate
//    d. Player category (Batsman, Bowler, Wicket keeper)
//    e. Team Country (India, Brazil, Canada, England, etc.)
//    f. No. of Test match (Per match 5 points)
//    g. No. of 1 day match (Per match 2 points)
//    h. No. of catch (Per catch 3 Points)
//    i. No. of Runs (Per run 1 point)
//    j. No. of Wicket (Per wicket 5 points)
//    k. No. of stumping (Per stumping 3 points)
//    l. Total points (Calculation)
}
