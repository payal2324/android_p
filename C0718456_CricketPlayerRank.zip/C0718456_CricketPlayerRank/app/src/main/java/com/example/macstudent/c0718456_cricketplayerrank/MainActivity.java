package com.example.macstudent.c0718456_cricketplayerrank;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
//    Button btnNext = (Button)findViewById(R.id.btnNext);
//        btnNext.setOnClickListener(new View.OnClickListener() {
//@Override
//public void onClick(View v) {
//        Intent intent = new Intent(getApplicationContext(),CalculationActivity.class);
//        startActivity(intent);
//        }
//        });