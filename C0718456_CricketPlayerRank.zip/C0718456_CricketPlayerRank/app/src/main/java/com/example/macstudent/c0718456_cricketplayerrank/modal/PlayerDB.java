package com.example.macstudent.c0718456_cricketplayerrank.modal;

/**
 * Created by macstudent on 2017-12-01.
 */

public class PlayerDB {





}
