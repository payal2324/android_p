# Application Description
Sample Example to demonstrate startActivityForResult(), SnackBar, ActionBar, FloatingActionButton and CoordinatorLayout 
