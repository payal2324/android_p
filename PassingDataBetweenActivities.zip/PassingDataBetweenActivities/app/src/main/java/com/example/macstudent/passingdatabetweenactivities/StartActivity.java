/*
 * Copyright (c) 2017. Pritesh Patel
 */

package com.example.macstudent.passingdatabetweenactivities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.SeekBar;
import android.widget.Toast;

public class StartActivity extends Activity {

    RadioGroup rg;
    CheckBox checkBoxone;
    SeekBar seekBar;
    RatingBar rb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        rg= (RadioGroup)findViewById(R.id.myRadioGroup);

        Button btnNext = (Button)findViewById(R.id.btnNext);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),FirstActivity.class);
                //intent.putExtra("name","Lambton College");
                intent.putExtra("id",1);
                startActivity(intent);
            }
        });

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(i == R.id.radioButtonFirst) {
                    Toast.makeText(StartActivity.this,"First", Toast.LENGTH_SHORT).show();
                }else  if(i == R.id.radioButtonSecond) {
                    Toast.makeText(StartActivity.this,"Second", Toast.LENGTH_SHORT).show();
                } if(i == R.id.radioButtonThird) {
                    Toast.makeText(StartActivity.this,"Third", Toast.LENGTH_SHORT).show();
                }
            }
        });

        checkBoxone = findViewById(R.id.checkBoxOne);


        checkBoxone.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(checkBoxone.isChecked())
                {
                    Toast.makeText(StartActivity.this,"ONE", Toast.LENGTH_SHORT).show();
                }
            }
        });

        seekBar = findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                Toast.makeText(StartActivity.this,"Value " + i, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        rb = findViewById(R.id.ratingBar);
        rb.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                Toast.makeText(StartActivity.this,"Value " + v, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
