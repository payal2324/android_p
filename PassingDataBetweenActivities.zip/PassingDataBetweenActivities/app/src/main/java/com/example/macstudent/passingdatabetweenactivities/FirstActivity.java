package com.example.macstudent.passingdatabetweenactivities;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;


//https://www.mkyong.com/android/android-spinner-drop-down-list-example/
public class FirstActivity extends Activity {

    TextView txtTitle;
    Spinner sp1, sp2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);

        txtTitle = (TextView)findViewById(R.id.txtTitle);

        Bundle b  = getIntent().getExtras();

        if( b!=null) {
            String title = "NO TITLE";
            int id = 0;
            if(b.containsKey("name")) {
                title = b.getString("name");
            }

             id = b.getInt("id");
            txtTitle.setText(id + "  " + title);
        }
        else
        {
            txtTitle.setText("No DATA");
        }

        sp1 = findViewById(R.id.spinner1);

       /* sp1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        sp1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        });*/

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(FirstActivity.this,sp1.getSelectedItem().toString(),Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        sp2 = findViewById(R.id.spinner2);
        List<String> list = new ArrayList<String>();
        list.add("list 1");
        list.add("list 2");
        list.add("list 3");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp2.setAdapter(dataAdapter);

        //MOdify after new item added
        list.add("LIST 4");
       // dataAdapter.notifyDataSetChanged();
    }
}
