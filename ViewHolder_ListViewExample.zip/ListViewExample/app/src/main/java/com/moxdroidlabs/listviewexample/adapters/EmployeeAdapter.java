package com.moxdroidlabs.listviewexample.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.moxdroidlabs.listviewexample.R;
import com.moxdroidlabs.listviewexample.model.Employee;

import java.util.ArrayList;

/**
 * Created by macstudent on 2017-11-28.
 */

public class EmployeeAdapter extends ArrayAdapter<Employee>
{

    public EmployeeAdapter(Context context, ArrayList<Employee> employeeArrayList)
    {
        super(context, 0, employeeArrayList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        // Get the data item for this position
        Employee employee = getItem(position);
        ViewHolder viewHolder;

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null)
        {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_employee, parent, false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
        }
        else
        {
            viewHolder = (ViewHolder)convertView.getTag();
        }

        // Populate the data into the template view using the data object
        viewHolder.tvEmployeeID.setText(String.valueOf(employee.getEmployeeId()));
        viewHolder.tvEmployeeName.setText(employee.getEmployeeName());

        return convertView;
    }

    private class ViewHolder
    {
        TextView tvEmployeeID;
        TextView tvEmployeeName;

        ViewHolder(View convertView)
        {
             tvEmployeeID = (TextView) convertView.findViewById(R.id.txtEmployeeID);
             tvEmployeeName = (TextView) convertView.findViewById(R.id.txtEmployeeName);
        }
    }
}
