package com.moxdroidlabs.listviewexample;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.moxdroidlabs.listviewexample.adapters.EmployeeAdapter;
import com.moxdroidlabs.listviewexample.model.Employee;

import java.util.ArrayList;
import java.util.Random;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class EmployeeActivity extends AppCompatActivity {

    @InjectView(R.id.lstEmployee)
    ListView lstEmployee;

    ArrayList<Employee>employeeArrayList;
    EmployeeAdapter employeeAdapter;

    public static void startIntent(Context context)
    {
        context.startActivity(new Intent(context,EmployeeActivity.class));
    }

    public static void startIntent(Context context, Bundle bundle)
    {
        Intent me = new Intent(context,EmployeeActivity.class);
        me.putExtras(bundle);
        context.startActivity(me);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee);
        ButterKnife.inject(this);

        getSharedPreferenceData();

        initData();

        employeeAdapter = new EmployeeAdapter(this,employeeArrayList);
        lstEmployee.setAdapter(employeeAdapter);

        lstEmployee.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Employee e = employeeArrayList.get(i);
                //employeeAdapter.add(new Employee(new Random().nextInt(100),"TEST-TEST"));
                Bundle bundle = new Bundle();
                bundle.putSerializable("emp",e);
                EmployeeDetailsActivity.startIntent(EmployeeActivity.this,bundle);
            }
        });



        employeeArrayList.add(new Employee(12,"Hello from Lambton"));
    }

    private void initData() {
        employeeArrayList = new ArrayList<>();
        employeeArrayList.add(new Employee(1,"Pritesh"));
        employeeArrayList.add(new Employee(2,"Denis"));
        employeeArrayList.add(new Employee(3,"Subham"));
        employeeArrayList.add(new Employee(4,"Payal"));
        employeeArrayList.add(new Employee(5,"Kirti"));
        employeeArrayList.add(new Employee(6,"Aaryash"));
        employeeArrayList.add(new Employee(7,"Karan"));
        employeeArrayList.add(new Employee(8,"Dhruvi"));
        employeeArrayList.add(new Employee(9,"Shweta"));
        employeeArrayList.add(new Employee(10,"Nikhil"));
    }

    void getSharedPreferenceData()
    {
        SharedPreferences preferences = getSharedPreferences("myPref",MODE_PRIVATE);

        int id = preferences.getInt("id",-1);
        String name = preferences.getString("name",null);

        if(name != null && id != -1)
        {
            Log.d("PREF", String.format("%d [ %s ]", id, name));
        }

    }
}
