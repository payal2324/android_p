package com.moxdroidlabs.sqlitedatabaseexample.db.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.moxdroidlabs.sqlitedatabaseexample.db.model.Contact;
import com.moxdroidlabs.sqlitedatabaseexample.db.model.Person;

/**
 * Created by macstudent on 2017-11-30.
 */

public class DBPerson {

    // Contacts table name
    static final String TABLE_PERSON = "persons";

    // Contacts Table Columns names
    static final String KEY_ID = "id";
    static final String KEY_NAME = "name";

    private DatabaseHandler databaseHandler;
    private Context context;

    public DBPerson(Context context) {
        this.context = context;
    }

    // Adding new person
    public void addPerson(Person person) {
        databaseHandler = new DatabaseHandler(context);

        SQLiteDatabase db = databaseHandler.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, person.get_name()); // Contact Name

        // Inserting Row
        db.insert(TABLE_PERSON, null, values);
        db.close(); // Closing database connection
    }

}
