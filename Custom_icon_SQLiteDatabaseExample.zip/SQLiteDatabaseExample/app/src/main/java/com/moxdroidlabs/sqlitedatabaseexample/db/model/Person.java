package com.moxdroidlabs.sqlitedatabaseexample.db.model;

/**
 * Created by macstudent on 2017-11-30.
 */

public class Person {
    int _id;
    String _name;

    public Person() {
    }

    public Person(int _id, String _name) {
        this._id = _id;
        this._name = _name;
    }

    public Person(String _name) {
        this._name = _name;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String get_name() {
        return _name;
    }

    public void set_name(String _name) {
        this._name = _name;
    }
}
