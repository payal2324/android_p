package com.moxdroidlabs.sqlitedatabaseexample;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.moxdroidlabs.sqlitedatabaseexample.adapter.ContactAdapter;
import com.moxdroidlabs.sqlitedatabaseexample.db.helper.DBContact;
import com.moxdroidlabs.sqlitedatabaseexample.db.model.Contact;

import java.util.ArrayList;
import java.util.List;

public class ContactListActivity extends Activity {

    ContactAdapter contactAdapter;
    ListView lstContact;
    ArrayList<Contact> contactList;

    public static void startIntent(Context context)
    {
        context.startActivity(new Intent(context,ContactListActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);

        lstContact = (ListView)findViewById(R.id.lstContact);

        DBContact dbContact = new DBContact(this);

        contactList = (ArrayList<Contact>) dbContact.getAllContacts();

        contactAdapter = new ContactAdapter(this,contactList);
        lstContact.setAdapter(contactAdapter);

        lstContact.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Contact e = contactList.get(i);
            }
        });
    }
}
