package com.example.macstudent.helloworld;

import android.app.Activity;
import android.os.Bundle;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SampleActivity extends Activity {

    EditText editNumber1, editNumber2;
    TextView textViewResult;
Button btnAdd,btnSub,btnMul,btnDiv;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sample_layout);



         editNumber1 =(EditText)findViewById(R.id.editNumber1);
        editNumber2 = (EditText)findViewById(R.id.editNumber2);
        textViewResult =(TextView)findViewById(R.id.textViewResult);
        btnAdd = (Button)findViewById(R.id.btnAdd);
        btnSub = (Button)findViewById(R.id.btnSub);
    }




    public void myclick(View view) {
        int a, b, c;
        a = Integer.parseInt(editNumber1.getText().toString());
        b = Integer.parseInt(editNumber2.getText().toString());
        switch( view.getId())
        {
            case R.id.btnAdd:
            {
                c = a+ b;
                Toast.makeText(this,"ADD" + c,Toast.LENGTH_LONG).show();
            }
        break;
            case R.id.btnSub:
            {
                c = a -  b;
               // mCount.setText(String.valueOf(Double.valueOf(mCount.getText().toString()) + 1));
                textViewResult.setText(String.valueOf(Integer.valueOf(c)));
                Toast.makeText(this,"Sub  : " +  c,Toast.LENGTH_LONG).show();
            }
            break;
    }

//    public void myClick(View view) {
//        switch (view.getId())
//        {
//            case R.id.btnAdd:
//            {
//                Toast.makeText(this,"Click",Toast.LENGTH_LONG).show();
//            }
//            break;
//        }

    }

}
