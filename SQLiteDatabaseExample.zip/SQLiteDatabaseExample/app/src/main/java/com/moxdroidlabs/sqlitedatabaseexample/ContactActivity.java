package com.moxdroidlabs.sqlitedatabaseexample;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.moxdroidlabs.sqlitedatabaseexample.db.helper.DBContact;
import com.moxdroidlabs.sqlitedatabaseexample.db.model.Contact;

import java.util.List;

public class ContactActivity extends Activity {

    Button btnAdd;
    EditText txtName;
    EditText txtPhoneNumber;

    DBContact dbContact;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ActionBar actionBar = getActionBar();
        if (actionBar != null) {
            actionBar.setTitle("Contact");
        }

        dbContact = new DBContact(this);

        txtName = (EditText)findViewById(R.id.edtStudentName);
        txtPhoneNumber= (EditText)findViewById(R.id.edtStudentPNo);
        btnAdd = (Button)findViewById(R.id.btnSave);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbContact.addContact(new Contact(txtName.getText().toString(), txtPhoneNumber.getText().toString()));
            }
        });



       /* // Reading all contacts
        Log.d("Reading: ", "Reading all contacts..");
        List<Contact> contacts = dbContact.getAllContacts();

        for (Contact cn : contacts) {
            String log = "Id: " + cn.getID() + " ,Name: " + cn.getName() + " ,Phone: " + cn.getPhoneNumber();
            // Writing Contacts to log
            Log.d("Name: ", log);
        }*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId()) {
            case R.id.action_add:
                ContactListActivity.startIntent(this);
                break;

        }
        return(super.onOptionsItemSelected(item));
    }
}
